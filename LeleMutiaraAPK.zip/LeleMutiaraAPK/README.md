# Lele Mutiara Pro 50H - APK

1. Buat repository baru di GitHub (github.com/new), nama bebas.
2. Upload SEMUA isi folder ini (termasuk folder .github) ke repository.
3. Buka tab "Actions" -> tunggu workflow "Build APK" selesai (hijau, +/- 3-5 menit).
4. Klik run tersebut -> bagian "Artifacts" -> unduh "Lele-Mutiara-Pro-50H-APK".
5. Ekstrak zip, kirim file .apk ke HP rekan, lalu install.
   (Izinkan "Install dari sumber tidak dikenal".)
